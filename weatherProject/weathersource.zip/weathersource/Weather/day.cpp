#include "day.h"

Day::Day()
{

}
