#include "widget.h"
#include "ui_widget.h"

#include <QMouseEvent>
#include <QDebug>
#include <qnetworkaccessmanager.h>
#include <qdir.h>
#include <QMessageBox>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QTextCodec>
#include <QPainter>


Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);


    //新建一个菜单组件
    menuQuit = new QMenu(this);

    //设置菜单项文字颜色：
    menuQuit->setStyleSheet("QMenu::item {color: white}");

    //为菜单组件添加一个动作
    QAction *openAct = new QAction(QIcon(":/back.png"), tr("退出"), this);
    menuQuit->addAction(openAct);

    //用户选择菜单项并点击后回调函数，退出程序
    connect(menuQuit,&QMenu::triggered,this,[=]{
        this->close();
    });


    natManager = new QNetworkAccessManager(this);

    //发送网络请求，创建网络响应
    QNetworkRequest ipRequest;
    ipRequest.setUrl(QUrl("http://whois.pconline.com.cn/ipJson.jsp?ip"));

    //get 网络请求怎么表示 QNetworkReply
    QNetworkReply *natReply = natManager->get(ipRequest);

    //QNetworkReply 提供信号 监测网络的执行情况
    connect(natReply,SIGNAL(finished()),this,SLOT(slotGetReplyFinished()));

    QNetworkAccessManager *manager = new QNetworkAccessManager(this);
    QNetworkRequest res(QUrl("http://gfeljm.tianqiapi.com/api?unescape=1&version=v9&appid=45579526&appsecret=xnqunNi9&city=" + cityName ));

    //网络请求后进行数据读取
    reply = manager->get(res);
    connect(reply,&QNetworkReply::finished,this,&Widget::readHttpReply);


    mWeekList << ui->labelDay1 << ui->labelDay2 << ui->labelDay3 << ui->labelDay4 << ui->labelDay5 << ui->labelDay6;
    mDateList << ui->labelDay1_1 << ui->labelDay2_1 << ui->labelDay3_1 << ui->labelDay4_1 << ui->labelDay5_1 << ui->labelDay6_1;
    mImgList << ui->labelWeather1 << ui->labelWeather2 << ui->labelWeather3 << ui->labelWeather4 << ui->labelWeather5 << ui->labelWeather6;
    mWeaList << ui->labelWeather1_1 << ui->labelWeather2_1 << ui->labelWeather3_1 << ui->labelWeather4_1 << ui->labelWeather5_1 << ui->labelWeather6_1;
    mAirLevelList << ui->labelAIR1 << ui->labelAIR2 << ui->labelAIR3 << ui->labelAIR4 << ui->labelAIR5 << ui->labelAIR6;
    mWinList << ui->labelWind1 << ui->labelWind2 << ui->labelWind3 << ui->labelWind4 << ui->labelWind5 << ui->labelWind6;
    mWinSpeedList << ui->labelWind1_1 << ui->labelWind2_1 << ui->labelWind3_1 << ui->labelWind4_1 << ui->labelWind5_1 << ui->labelWind6_1;


    //根据keys,设置icon的路径
    mTypeMap.insert("小雨转晴",":/type/XiaoYUZhuanQing.png");
    mTypeMap.insert("暴雪",":/type/BaoXue.png");
    mTypeMap.insert("暴雨",":/type/BaoYu. png");
    mTypeMap.insert("暴雨到大暴雨",":/type/BaoYuDaoDaBaoYu.png");
    mTypeMap.insert("大暴雨",":/type/DaBaoYu.png");
    mTypeMap.insert("大暴雨到特大暴雨",":/type/DaBaoYuDaoTeDaBaoYu.png");
    mTypeMap.insert("大到暴雪",":/type/DaDaoBaoXue.png");
    mTypeMap.insert("大雪",":/type/DaXue.png");
    mTypeMap.insert("大雨",":/type/DaYu.png");
    mTypeMap.insert("冻雨",":/type/DongYu.png");
    mTypeMap.insert("多云",":/type/DuoYun.png");
    mTypeMap.insert("浮沉",":/type/FuChen.png");
    mTypeMap.insert("雷阵雨",":/type/LeiZhenYu.png");
    mTypeMap.insert("霾",":/type/Mai.png");
    mTypeMap.insert("晴",":/type/sun.png");
    mTypeMap.insert("特大暴雨",":/type/TeDaBaoYu.png");
    mTypeMap.insert("雾",":/type/Wu.png");
    mTypeMap.insert("小雪",":/type/XiaoXue.png");
    mTypeMap.insert("小雨",":/type/XiaoYu.png");
    mTypeMap.insert("阴",":/type/Yin.png");
    mTypeMap.insert("雨夹雪",":/type/YuJiaXue.png");
    mTypeMap.insert("阵雪",":/type/ZhenXue.png");
    mTypeMap.insert("阵雨",":/type/ZhenYu.png");
    mTypeMap.insert("中雪",":/type/ZhongXue.png");
    mTypeMap.insert("中雨",":/type/ZhongYu.png");
    mTypeMap.insert("阴转多云",":/type/YinZhuanDuoYun.png");
    mTypeMap.insert("多云转小雨",":/type/DuoYunZhuanXiaoYu.png");
    mTypeMap.insert("阴转晴",":/type/YinZhuanQing.png");
    mTypeMap.insert("晴转多云",":/type/QingZhuanDuoYun.png");
    mTypeMap.insert("多云转阴",":/type/DuoYunZhuanYin.png");


    ui->widgetLine1->installEventFilter(this);
    ui->widgetLine2->installEventFilter(this);
}

/*
 QNetworkAccessManager *manager = new QNetworkAccessManager(this);
 connect(manager, &QNetworkAccessManager::finished,
         this, &MyClass::replyFinished);

 manager->get(QNetworkRequest(QUrl("http://qt-project.org")));
*/



Widget::~Widget()
{
    reply->deleteLater();
}


void Widget::mousePressEvent(QMouseEvent *event)
{
    if(event->button() == Qt::RightButton)
    {
        //qDebug() << "Right Mouse is clicked";
        menuQuit->exec(QCursor::pos());
    }

    //鼠标当前位置 窗口当前位置 窗口新位置
    if(event->button() == Qt::LeftButton)
    {
        qDebug() << event->globalPos() << this->pos();

        mOffset = event->globalPos()-this->pos();
    }
}


bool Widget::eventFilter(QObject *watched, QEvent *event)
{
    if(watched == ui->widgetLine1 && event->type() == QEvent::Paint)
    {
        drawTemHighLine();
        return true; //表示事件已被处理
    }

    if(watched == ui->widgetLine2 && event->type() == QEvent::Paint)
    {
        drawTemLowLine();
        return true; //表示事件已被处理
    }
}

void Widget::on_pushButtonBack_clicked()
{
    emit this->back();
}


void Widget::parseWeatherJsonData(QByteArray rawData)
{
    QJsonDocument jsonObj = QJsonDocument::fromJson(rawData);
    if(!jsonObj.isNull() && jsonObj.isObject())
    {
        QJsonObject rootObj = jsonObj.object();
        QString city        = rootObj["city"].toString();
        ui->labelCity->setText(city);

        QJsonArray dataArray = rootObj["data"].toArray();
        QJsonObject todayObj = dataArray[0].toObject();

        QString date  = todayObj["date"].toString();
        QString week  = todayObj["week"].toString();
        ui->labelDate->setText(date + "  " + week);

        QString wea   = todayObj["wea"].toString();
        ui->labelWeather->setText(wea);
        ui->labelWeathericon->setPixmap(mTypeMap[wea]);

        QString tem   = todayObj["tem"].toString();
        ui->labelTem->setText(tem + "℃");

        QString tem1  = todayObj["tem1"].toString();
        QString tem2  = todayObj["tem2"].toString();
        ui->labelTemRange->setText(tem2 + "℃" + "~" + tem1 + "℃");

        QJsonArray winArray = todayObj["win"].toArray();
        QString win         = winArray[0].toString();
        QString win_speed   = todayObj["win_speed"].toString();
        ui->labelFXType->setText(win);
        ui->labelFXLevel->setText(win_speed);

        QString humidity  = todayObj["humidity"].toString();
        ui->labelSDLevel->setText(humidity);

        QString pressure = todayObj["pressure"].toString();
        ui->labelPRLevel->setText(pressure);

        QString air_level = todayObj["air_level"].toString();
        ui->labelAIRLevel->setText(air_level);

        QJsonArray indexArray = todayObj["index"].toArray();
        QJsonObject clothesObj = indexArray[3].toObject();
        QString title = clothesObj["title"].toString();
        QString desc  = clothesObj["desc"].toString();
        ui->labelClothes->setText(title + ": " + desc);

        QJsonArray weaArray = rootObj["data"].toArray();
        for(int i = 0; i < weaArray.size()-1; i++)
        {
            QJsonObject Obj = weaArray[i].toObject();
            days[i].date = Obj["date"].toString().mid(5);
            days[i].week = Obj["week"].toString();
            days[i].wea  = Obj["wea"].toString();
            QJsonArray winArray = Obj["win"].toArray();
            days[i].win  = winArray[0].toString();
            days[i].win_speed = Obj["win_speed"].toString();
            days[i].air_level = Obj["air_level"].toString();

            temHigh[i] = Obj["tem1"].toString();
            temLow[i] = Obj["tem2"].toString();
        }

        for(int i = 0; i < 6; i++)
        {
            mWeekList[i]->setText(days[i].week);
            mDateList[i]->setText(days[i].date);
            mImgList[i]->setPixmap(mTypeMap[days[i].wea]);
            mWeaList[i]->setText(days[i].wea);

            QString airQ = days[i].air_level;
            mAirLevelList[i]->setText(days[i].air_level);
            if(airQ == "优")
            {
                mAirLevelList[i]->setStyleSheet("background-color: rgb(150, 213, 32); border-radius: 5px;");
            }
            else
            {
                mAirLevelList[i]->setStyleSheet("background-color: rgb(255, 187, 69); border-radius: 5px;");
            }



            mWinList[i]->setText(days[i].win);
            mWinSpeedList[i]->setText(days[i].win_speed);
        }
        mWeekList[0]->setText("今天");
        mWeekList[1]->setText("明天");
        mWeekList[2]->setText("后天");
        update();
    }
}

void Widget::drawTemHighLine()
{
    QPainter painter(ui->widgetLine1);
    painter.setBrush(Qt::yellow);
    painter.setPen(QPen(Qt::yellow, 2));
    painter.setRenderHint(QPainter::Antialiasing,true);


    //定义出六个点
    QPoint points[6];

    int sum = 0;
    double highavg = 0.0;
    double offset = 0.0;

    for(int i = 0; i < 5; i++)
    {
        sum += temHigh[i].toUInt();
    }

    highavg = sum/6.0;

    for(int i = 0; i < 6; i++)
    {
        points[i].setX(mAirLevelList[i]->x() + mAirLevelList[i]->width()/2);
        offset = temHigh[i].toUInt()-highavg;
        points[i].setY(ui->widgetLine1->height()/2 - offset);

        painter.drawEllipse(QPoint(points[i]),3,3);

        //画出当天温度
        QString tem = temHigh[i] + "°";
        painter.drawText(points[i].x()-10,points[i].y()-8,tem);
        if(i > 0)
        {
            painter.drawLine(points[i-1],points[i]);
        }
    }

}

void Widget::drawTemLowLine()
{
    QPainter painter(ui->widgetLine2);
    painter.setBrush(QBrush(QColor(37,252,255)));
    painter.setPen(QPen(QColor(37,252,255),2));
    painter.setRenderHint(QPainter::Antialiasing,true);

    //定义出六个点
    QPoint points[6];

    int sum = 0;
    double lowavg = 0.0;
    double offset = 0.0;

    for(int i = 0; i < 5; i++)
    {
        sum += temLow[i].toUInt();
    }

    lowavg = sum/6.0;

    for(int i = 0; i < 6; i++)
    {
        points[i].setX(mAirLevelList[i]->x() + mAirLevelList[i]->width()/2);
        offset = (temLow[i].toUInt()-lowavg)*3;
        points[i].setY(ui->widgetLine2->height()/2 - offset);

        //画出6个点
        painter.drawEllipse(QPoint(points[i]),3,3);
        //画出当天温度
        QString tem = temLow[i] + "°";
        painter.drawText(points[i].x()-10,points[i].y()-8,tem);

        if(i > 0)
        {
            painter.drawLine(points[i-1],points[i]);
        }
    }

}


void Widget::readHttpReply()
{

    int resCode = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();

    if((reply->error() == QNetworkReply::NoError) && (resCode == 200))
    {
        QByteArray data = reply->readAll();
        parseWeatherJsonData(data);
    }
    else
    {

        QMessageBox mes;
        mes.setWindowTitle("错误");
        mes.setText("网络请求失败");
        mes.setStyleSheet("QPushButton {color: red}");
        mes.setStandardButtons(QMessageBox::Ok);
        mes.exec();
    }


    //数据太多 无法直接在控制台打印 所以写入文件
/*    QFile file("temp.json");
    if (file.open(QIODevice::WriteOnly)) {
        file.write(data);
        file.close();
        qDebug() << "数据已写入:" << QDir::current().absoluteFilePath("temp.json");
    }*/
}

void Widget::slotGetReplyFinished()
{
    QNetworkReply *reply = (QNetworkReply *)sender();

    QTextCodec *codec = QTextCodec::codecForName("gbk");

    QString data = codec->toUnicode(reply->readAll());

    int citylocationStart = data.indexOf("city") + 7;
    int citylocationEnd = data.indexOf("cityCode") - 4;
    cityName = data.mid(citylocationStart,citylocationEnd - citylocationStart);
    reply->deleteLater(); //防止内存泄露
    qDebug() << cityName;

}

