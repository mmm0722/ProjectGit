#ifndef WEATHER_H
#define WEATHER_H

#include <QWidget>
#include <qmenu.h>
#include <QLabel>
#include <qnetworkreply.h>
#include "day.h"

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    Day days[7];
    QList<QLabel *> mWeekList;
    QList<QLabel *> mDateList;
    QList<QLabel *> mImgList;
    QList<QLabel *> mWeaList;
    QList<QLabel *> mAirLevelList;
    QList<QLabel *> mWinList;
    QList<QLabel *> mWinSpeedList;

    explicit Widget(QWidget *parent = nullptr);
    ~Widget();

signals:
    void back();

private:
     Ui::Widget *ui;
    QMenu *menuQuit;
    QPoint mOffset;
    QNetworkReply *reply;
    QNetworkAccessManager *natManager;
    QString cityName;
    QMap<QString,QString> mTypeMap;
    QString temHigh[6];
    QString temLow[6];

    void parseWeatherJsonData(QByteArray rawData);
    void drawTemHighLine();
    void drawTemLowLine();

protected:
    void mousePressEvent(QMouseEvent *event);
    bool eventFilter(QObject *watched , QEvent *event);

private slots:
    void on_pushButtonBack_clicked();

    void readHttpReply();

    void slotGetReplyFinished();
};

#endif // WEATHER_H
