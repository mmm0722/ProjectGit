#ifndef DAY_H
#define DAY_H

#include <QString>



class Day
{
public:
    Day();
        QString date;
        QString week;
        QString wea;
        QString win;
        QString win_speed;
        QString air_level;
};

#endif // DAY_H
