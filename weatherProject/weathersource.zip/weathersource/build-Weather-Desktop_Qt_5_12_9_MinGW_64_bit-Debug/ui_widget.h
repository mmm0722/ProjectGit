/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QVBoxLayout *verticalLayout_24;
    QWidget *widget01;
    QHBoxLayout *horizontalLayout_7;
    QPushButton *pushButtonBack;
    QSpacerItem *horizontalSpacer_2;
    QLabel *labelDate;
    QWidget *widget02;
    QHBoxLayout *horizontalLayout_6;
    QHBoxLayout *horizontalLayout_5;
    QLabel *labelWeathericon;
    QGridLayout *gridLayout_2;
    QLabel *labelTem;
    QLabel *labelWeather;
    QSpacerItem *horizontalSpacer;
    QLabel *labelCity;
    QLabel *label;
    QLabel *labelTemRange;
    QSpacerItem *horizontalSpacer_3;
    QWidget *widget03;
    QVBoxLayout *verticalLayout;
    QLabel *labelClothes;
    QWidget *widget0301;
    QGridLayout *gridLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *labelFX;
    QVBoxLayout *verticalLayout_2;
    QLabel *labelFXType;
    QLabel *labelFXLevel;
    QHBoxLayout *horizontalLayout_2;
    QLabel *labelPR;
    QVBoxLayout *verticalLayout_3;
    QLabel *labelPRType;
    QLabel *labelPRLevel;
    QHBoxLayout *horizontalLayout_4;
    QLabel *labelAIR;
    QVBoxLayout *verticalLayout_5;
    QLabel *labelAIRType;
    QLabel *labelAIRLevel;
    QHBoxLayout *horizontalLayout_3;
    QLabel *labelSD;
    QVBoxLayout *verticalLayout_4;
    QLabel *labelSDType;
    QLabel *labelSDLevel;
    QWidget *widget04;
    QVBoxLayout *verticalLayout_25;
    QWidget *widgetDay;
    QHBoxLayout *horizontalLayout_9;
    QVBoxLayout *verticalLayout_6;
    QLabel *labelDay1;
    QLabel *labelDay1_1;
    QVBoxLayout *verticalLayout_7;
    QLabel *labelDay2;
    QLabel *labelDay2_1;
    QVBoxLayout *verticalLayout_8;
    QLabel *labelDay3;
    QLabel *labelDay3_1;
    QVBoxLayout *verticalLayout_9;
    QLabel *labelDay4;
    QLabel *labelDay4_1;
    QVBoxLayout *verticalLayout_10;
    QLabel *labelDay5;
    QLabel *labelDay5_1;
    QVBoxLayout *verticalLayout_11;
    QLabel *labelDay6;
    QLabel *labelDay6_1;
    QWidget *widgetWeather;
    QHBoxLayout *horizontalLayout_10;
    QVBoxLayout *verticalLayout_17;
    QLabel *labelWeather1;
    QLabel *labelWeather1_1;
    QVBoxLayout *verticalLayout_12;
    QLabel *labelWeather2;
    QLabel *labelWeather2_1;
    QVBoxLayout *verticalLayout_15;
    QLabel *labelWeather3;
    QLabel *labelWeather3_1;
    QVBoxLayout *verticalLayout_14;
    QLabel *labelWeather4;
    QLabel *labelWeather4_1;
    QVBoxLayout *verticalLayout_16;
    QLabel *labelWeather5;
    QLabel *labelWeather5_1;
    QVBoxLayout *verticalLayout_13;
    QLabel *labelWeather6;
    QLabel *labelWeather6_1;
    QWidget *widget0401;
    QVBoxLayout *verticalLayout_26;
    QWidget *widgetLine1;
    QWidget *widgetLine2;
    QWidget *widgetAir;
    QHBoxLayout *horizontalLayout_8;
    QLabel *labelAIR1;
    QLabel *labelAIR2;
    QLabel *labelAIR3;
    QLabel *labelAIR4;
    QLabel *labelAIR5;
    QLabel *labelAIR6;
    QWidget *widgetWind;
    QHBoxLayout *horizontalLayout_11;
    QVBoxLayout *verticalLayout_18;
    QLabel *labelWind1;
    QLabel *labelWind1_1;
    QVBoxLayout *verticalLayout_19;
    QLabel *labelWind2;
    QLabel *labelWind2_1;
    QVBoxLayout *verticalLayout_20;
    QLabel *labelWind3;
    QLabel *labelWind3_1;
    QVBoxLayout *verticalLayout_21;
    QLabel *labelWind4;
    QLabel *labelWind4_1;
    QVBoxLayout *verticalLayout_22;
    QLabel *labelWind5;
    QLabel *labelWind5_1;
    QVBoxLayout *verticalLayout_23;
    QLabel *labelWind6;
    QLabel *labelWind6_1;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(1024, 600);
        Widget->setMinimumSize(QSize(1024, 600));
        Widget->setMaximumSize(QSize(1024, 600));
        Widget->setStyleSheet(QString::fromUtf8("background-color: rgb(20, 20, 20);"));
        verticalLayout_24 = new QVBoxLayout(Widget);
        verticalLayout_24->setSpacing(5);
        verticalLayout_24->setObjectName(QString::fromUtf8("verticalLayout_24"));
        verticalLayout_24->setContentsMargins(-1, 5, -1, 8);
        widget01 = new QWidget(Widget);
        widget01->setObjectName(QString::fromUtf8("widget01"));
        widget01->setStyleSheet(QString::fromUtf8("color:rgb(225,225,225);"));
        horizontalLayout_7 = new QHBoxLayout(widget01);
        horizontalLayout_7->setSpacing(30);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        horizontalLayout_7->setContentsMargins(-1, 0, 0, 0);
        pushButtonBack = new QPushButton(widget01);
        pushButtonBack->setObjectName(QString::fromUtf8("pushButtonBack"));
        pushButtonBack->setMinimumSize(QSize(35, 35));
        pushButtonBack->setStyleSheet(QString::fromUtf8("border-image: url(:/back.png);\n"
"\n"
""));

        horizontalLayout_7->addWidget(pushButtonBack);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_2);

        labelDate = new QLabel(widget01);
        labelDate->setObjectName(QString::fromUtf8("labelDate"));
        labelDate->setMinimumSize(QSize(32, 20));
        QFont font;
        font.setPointSize(10);
        labelDate->setFont(font);
        labelDate->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_7->addWidget(labelDate);

        horizontalLayout_7->setStretch(2, 2);

        verticalLayout_24->addWidget(widget01);

        widget02 = new QWidget(Widget);
        widget02->setObjectName(QString::fromUtf8("widget02"));
        widget02->setStyleSheet(QString::fromUtf8("color:rgb(225,225,225);"));
        horizontalLayout_6 = new QHBoxLayout(widget02);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        labelWeathericon = new QLabel(widget02);
        labelWeathericon->setObjectName(QString::fromUtf8("labelWeathericon"));
        labelWeathericon->setMinimumSize(QSize(64, 64));
        labelWeathericon->setMaximumSize(QSize(64, 64));
        labelWeathericon->setTextFormat(Qt::AutoText);
        labelWeathericon->setPixmap(QPixmap(QString::fromUtf8(":/sun.png")));
        labelWeathericon->setScaledContents(false);

        horizontalLayout_5->addWidget(labelWeathericon);

        gridLayout_2 = new QGridLayout();
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        labelTem = new QLabel(widget02);
        labelTem->setObjectName(QString::fromUtf8("labelTem"));
        QFont font1;
        font1.setPointSize(20);
        labelTem->setFont(font1);

        gridLayout_2->addWidget(labelTem, 0, 0, 1, 1);

        labelWeather = new QLabel(widget02);
        labelWeather->setObjectName(QString::fromUtf8("labelWeather"));
        QFont font2;
        font2.setPointSize(12);
        labelWeather->setFont(font2);
        labelWeather->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(labelWeather, 1, 0, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer, 0, 3, 1, 1);

        labelCity = new QLabel(widget02);
        labelCity->setObjectName(QString::fromUtf8("labelCity"));
        labelCity->setFont(font);

        gridLayout_2->addWidget(labelCity, 0, 4, 1, 1);

        label = new QLabel(widget02);
        label->setObjectName(QString::fromUtf8("label"));
        label->setFont(font2);
        label->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label, 0, 2, 1, 1);

        labelTemRange = new QLabel(widget02);
        labelTemRange->setObjectName(QString::fromUtf8("labelTemRange"));
        labelTemRange->setFont(font2);

        gridLayout_2->addWidget(labelTemRange, 1, 2, 1, 2);

        horizontalSpacer_3 = new QSpacerItem(80, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer_3, 1, 1, 1, 1);


        horizontalLayout_5->addLayout(gridLayout_2);


        horizontalLayout_6->addLayout(horizontalLayout_5);


        verticalLayout_24->addWidget(widget02);

        widget03 = new QWidget(Widget);
        widget03->setObjectName(QString::fromUtf8("widget03"));
        widget03->setStyleSheet(QString::fromUtf8("color:rgb(225,225,225);"));
        verticalLayout = new QVBoxLayout(widget03);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        labelClothes = new QLabel(widget03);
        labelClothes->setObjectName(QString::fromUtf8("labelClothes"));
        labelClothes->setFont(font2);

        verticalLayout->addWidget(labelClothes);

        widget0301 = new QWidget(widget03);
        widget0301->setObjectName(QString::fromUtf8("widget0301"));
        widget0301->setMaximumSize(QSize(16777215, 110));
        widget0301->setStyleSheet(QString::fromUtf8("background-color: rgb(208, 107, 39);\n"
"border-radius: 10px;"));
        gridLayout = new QGridLayout(widget0301);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setHorizontalSpacing(80);
        gridLayout->setVerticalSpacing(5);
        gridLayout->setContentsMargins(100, 3, 100, 3);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        labelFX = new QLabel(widget0301);
        labelFX->setObjectName(QString::fromUtf8("labelFX"));
        labelFX->setMinimumSize(QSize(0, 40));
        labelFX->setPixmap(QPixmap(QString::fromUtf8(":/wi-cloudy-windy.png")));
        labelFX->setScaledContents(false);
        labelFX->setAlignment(Qt::AlignCenter);

        horizontalLayout->addWidget(labelFX);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        labelFXType = new QLabel(widget0301);
        labelFXType->setObjectName(QString::fromUtf8("labelFXType"));
        labelFXType->setFont(font);
        labelFXType->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(labelFXType);

        labelFXLevel = new QLabel(widget0301);
        labelFXLevel->setObjectName(QString::fromUtf8("labelFXLevel"));
        labelFXLevel->setFont(font);
        labelFXLevel->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(labelFXLevel);


        horizontalLayout->addLayout(verticalLayout_2);


        gridLayout->addLayout(horizontalLayout, 0, 0, 1, 1);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        labelPR = new QLabel(widget0301);
        labelPR->setObjectName(QString::fromUtf8("labelPR"));
        labelPR->setMinimumSize(QSize(0, 45));
        labelPR->setPixmap(QPixmap(QString::fromUtf8(":/pressure.png")));
        labelPR->setScaledContents(false);
        labelPR->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(labelPR);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        labelPRType = new QLabel(widget0301);
        labelPRType->setObjectName(QString::fromUtf8("labelPRType"));
        labelPRType->setFont(font);
        labelPRType->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(labelPRType);

        labelPRLevel = new QLabel(widget0301);
        labelPRLevel->setObjectName(QString::fromUtf8("labelPRLevel"));
        labelPRLevel->setFont(font);
        labelPRLevel->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(labelPRLevel);


        horizontalLayout_2->addLayout(verticalLayout_3);


        gridLayout->addLayout(horizontalLayout_2, 0, 1, 1, 1);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        labelAIR = new QLabel(widget0301);
        labelAIR->setObjectName(QString::fromUtf8("labelAIR"));
        labelAIR->setMinimumSize(QSize(0, 45));
        labelAIR->setPixmap(QPixmap(QString::fromUtf8(":/air.png")));
        labelAIR->setScaledContents(false);
        labelAIR->setAlignment(Qt::AlignCenter);

        horizontalLayout_4->addWidget(labelAIR);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        labelAIRType = new QLabel(widget0301);
        labelAIRType->setObjectName(QString::fromUtf8("labelAIRType"));
        labelAIRType->setFont(font);
        labelAIRType->setAlignment(Qt::AlignCenter);

        verticalLayout_5->addWidget(labelAIRType);

        labelAIRLevel = new QLabel(widget0301);
        labelAIRLevel->setObjectName(QString::fromUtf8("labelAIRLevel"));
        labelAIRLevel->setFont(font);
        labelAIRLevel->setAlignment(Qt::AlignCenter);

        verticalLayout_5->addWidget(labelAIRLevel);


        horizontalLayout_4->addLayout(verticalLayout_5);


        gridLayout->addLayout(horizontalLayout_4, 1, 1, 1, 1);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        labelSD = new QLabel(widget0301);
        labelSD->setObjectName(QString::fromUtf8("labelSD"));
        labelSD->setMinimumSize(QSize(0, 40));
        labelSD->setPixmap(QPixmap(QString::fromUtf8(":/wi-humidity.png")));
        labelSD->setScaledContents(false);
        labelSD->setAlignment(Qt::AlignCenter);

        horizontalLayout_3->addWidget(labelSD);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        labelSDType = new QLabel(widget0301);
        labelSDType->setObjectName(QString::fromUtf8("labelSDType"));
        labelSDType->setFont(font);
        labelSDType->setAlignment(Qt::AlignCenter);

        verticalLayout_4->addWidget(labelSDType);

        labelSDLevel = new QLabel(widget0301);
        labelSDLevel->setObjectName(QString::fromUtf8("labelSDLevel"));
        labelSDLevel->setFont(font);
        labelSDLevel->setAlignment(Qt::AlignCenter);

        verticalLayout_4->addWidget(labelSDLevel);


        horizontalLayout_3->addLayout(verticalLayout_4);


        gridLayout->addLayout(horizontalLayout_3, 1, 0, 1, 1);


        verticalLayout->addWidget(widget0301);


        verticalLayout_24->addWidget(widget03);

        widget04 = new QWidget(Widget);
        widget04->setObjectName(QString::fromUtf8("widget04"));
        widget04->setStyleSheet(QString::fromUtf8(""));
        verticalLayout_25 = new QVBoxLayout(widget04);
        verticalLayout_25->setSpacing(3);
        verticalLayout_25->setObjectName(QString::fromUtf8("verticalLayout_25"));
        verticalLayout_25->setContentsMargins(0, 0, 0, 0);
        widgetDay = new QWidget(widget04);
        widgetDay->setObjectName(QString::fromUtf8("widgetDay"));
        widgetDay->setMinimumSize(QSize(0, 40));
        widgetDay->setMaximumSize(QSize(16777215, 40));
        widgetDay->setStyleSheet(QString::fromUtf8("color:rgb(225,225,225);"));
        horizontalLayout_9 = new QHBoxLayout(widgetDay);
        horizontalLayout_9->setSpacing(5);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        horizontalLayout_9->setContentsMargins(0, 0, 0, 0);
        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setSpacing(0);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        labelDay1 = new QLabel(widgetDay);
        labelDay1->setObjectName(QString::fromUtf8("labelDay1"));
        labelDay1->setFont(font);
        labelDay1->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 192, 203);\n"
"border-radius: 7px;\n"
"border-bottom-right-radius:0px;\n"
"border-bottom-left-radius:0px;"));
        labelDay1->setAlignment(Qt::AlignCenter);

        verticalLayout_6->addWidget(labelDay1);

        labelDay1_1 = new QLabel(widgetDay);
        labelDay1_1->setObjectName(QString::fromUtf8("labelDay1_1"));
        labelDay1_1->setFont(font);
        labelDay1_1->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 192, 203);\n"
"border-radius: 7px;\n"
"border-top-right-radius:0px;\n"
"border-top-left-radius:0px;"));
        labelDay1_1->setAlignment(Qt::AlignCenter);

        verticalLayout_6->addWidget(labelDay1_1);


        horizontalLayout_9->addLayout(verticalLayout_6);

        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setSpacing(0);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        labelDay2 = new QLabel(widgetDay);
        labelDay2->setObjectName(QString::fromUtf8("labelDay2"));
        labelDay2->setFont(font);
        labelDay2->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 192, 203);\n"
"border-radius: 7px;\n"
"border-bottom-right-radius:0px;\n"
"border-bottom-left-radius:0px;"));
        labelDay2->setAlignment(Qt::AlignCenter);

        verticalLayout_7->addWidget(labelDay2);

        labelDay2_1 = new QLabel(widgetDay);
        labelDay2_1->setObjectName(QString::fromUtf8("labelDay2_1"));
        labelDay2_1->setFont(font);
        labelDay2_1->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 192, 203);\n"
"border-radius: 7px;\n"
"border-top-right-radius:0px;\n"
"border-top-left-radius:0px;;"));
        labelDay2_1->setAlignment(Qt::AlignCenter);

        verticalLayout_7->addWidget(labelDay2_1);


        horizontalLayout_9->addLayout(verticalLayout_7);

        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setSpacing(0);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        labelDay3 = new QLabel(widgetDay);
        labelDay3->setObjectName(QString::fromUtf8("labelDay3"));
        labelDay3->setFont(font);
        labelDay3->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 192, 203);\n"
"border-radius: 7px;\n"
"border-bottom-right-radius:0px;\n"
"border-bottom-left-radius:0px;"));
        labelDay3->setAlignment(Qt::AlignCenter);

        verticalLayout_8->addWidget(labelDay3);

        labelDay3_1 = new QLabel(widgetDay);
        labelDay3_1->setObjectName(QString::fromUtf8("labelDay3_1"));
        labelDay3_1->setFont(font);
        labelDay3_1->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 192, 203);\n"
"border-radius: 7px;\n"
"border-top-right-radius:0px;\n"
"border-top-left-radius:0px;"));
        labelDay3_1->setAlignment(Qt::AlignCenter);

        verticalLayout_8->addWidget(labelDay3_1);


        horizontalLayout_9->addLayout(verticalLayout_8);

        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setSpacing(0);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        labelDay4 = new QLabel(widgetDay);
        labelDay4->setObjectName(QString::fromUtf8("labelDay4"));
        labelDay4->setFont(font);
        labelDay4->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 192, 203);\n"
"border-radius: 7px;\n"
"border-bottom-right-radius:0px;\n"
"border-bottom-left-radius:0px;"));
        labelDay4->setAlignment(Qt::AlignCenter);

        verticalLayout_9->addWidget(labelDay4);

        labelDay4_1 = new QLabel(widgetDay);
        labelDay4_1->setObjectName(QString::fromUtf8("labelDay4_1"));
        labelDay4_1->setFont(font);
        labelDay4_1->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 192, 203);\n"
"border-radius: 7px;\n"
"border-top-right-radius:0px;\n"
"border-top-left-radius:0px;"));
        labelDay4_1->setAlignment(Qt::AlignCenter);

        verticalLayout_9->addWidget(labelDay4_1);


        horizontalLayout_9->addLayout(verticalLayout_9);

        verticalLayout_10 = new QVBoxLayout();
        verticalLayout_10->setSpacing(0);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        labelDay5 = new QLabel(widgetDay);
        labelDay5->setObjectName(QString::fromUtf8("labelDay5"));
        labelDay5->setFont(font);
        labelDay5->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 192, 203);\n"
"border-radius: 7px;\n"
"border-bottom-right-radius:0px;\n"
"border-bottom-left-radius:0px;"));
        labelDay5->setAlignment(Qt::AlignCenter);

        verticalLayout_10->addWidget(labelDay5);

        labelDay5_1 = new QLabel(widgetDay);
        labelDay5_1->setObjectName(QString::fromUtf8("labelDay5_1"));
        labelDay5_1->setFont(font);
        labelDay5_1->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 192, 203);\n"
"border-radius: 7px;\n"
"border-top-right-radius:0px;\n"
"border-top-left-radius:0px;"));
        labelDay5_1->setAlignment(Qt::AlignCenter);

        verticalLayout_10->addWidget(labelDay5_1);


        horizontalLayout_9->addLayout(verticalLayout_10);

        verticalLayout_11 = new QVBoxLayout();
        verticalLayout_11->setSpacing(0);
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        labelDay6 = new QLabel(widgetDay);
        labelDay6->setObjectName(QString::fromUtf8("labelDay6"));
        labelDay6->setFont(font);
        labelDay6->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 192, 203);\n"
"border-radius: 7px;\n"
"border-bottom-right-radius:0px;\n"
"border-bottom-left-radius:0px;"));
        labelDay6->setAlignment(Qt::AlignCenter);

        verticalLayout_11->addWidget(labelDay6);

        labelDay6_1 = new QLabel(widgetDay);
        labelDay6_1->setObjectName(QString::fromUtf8("labelDay6_1"));
        labelDay6_1->setFont(font);
        labelDay6_1->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 192, 203);\n"
"border-radius: 7px;\n"
"border-top-right-radius:0px;\n"
"border-top-left-radius:0px;"));
        labelDay6_1->setAlignment(Qt::AlignCenter);

        verticalLayout_11->addWidget(labelDay6_1);


        horizontalLayout_9->addLayout(verticalLayout_11);


        verticalLayout_25->addWidget(widgetDay);

        widgetWeather = new QWidget(widget04);
        widgetWeather->setObjectName(QString::fromUtf8("widgetWeather"));
        widgetWeather->setMinimumSize(QSize(0, 68));
        widgetWeather->setMaximumSize(QSize(16777215, 80));
        widgetWeather->setStyleSheet(QString::fromUtf8("color:rgb(225,225,225);"));
        horizontalLayout_10 = new QHBoxLayout(widgetWeather);
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        horizontalLayout_10->setContentsMargins(0, 0, 0, 0);
        verticalLayout_17 = new QVBoxLayout();
        verticalLayout_17->setSpacing(0);
        verticalLayout_17->setObjectName(QString::fromUtf8("verticalLayout_17"));
        labelWeather1 = new QLabel(widgetWeather);
        labelWeather1->setObjectName(QString::fromUtf8("labelWeather1"));
        labelWeather1->setMinimumSize(QSize(159, 50));
        labelWeather1->setMaximumSize(QSize(159, 50));
        labelWeather1->setStyleSheet(QString::fromUtf8("background-color: rgb(74,74,74);\n"
"border-radius: 7px;\n"
"border-bottom-right-radius:0px;\n"
"border-bottom-left-radius:0px;"));
        labelWeather1->setPixmap(QPixmap(QString::fromUtf8(":/sun.png")));
        labelWeather1->setAlignment(Qt::AlignCenter);

        verticalLayout_17->addWidget(labelWeather1);

        labelWeather1_1 = new QLabel(widgetWeather);
        labelWeather1_1->setObjectName(QString::fromUtf8("labelWeather1_1"));
        labelWeather1_1->setMinimumSize(QSize(0, 20));
        labelWeather1_1->setFont(font);
        labelWeather1_1->setStyleSheet(QString::fromUtf8("background-color: rgb(74,74,74);\n"
"border-radius: 7px;\n"
"border-top-right-radius:0px;\n"
"border-top-left-radius:0px;"));
        labelWeather1_1->setAlignment(Qt::AlignCenter);

        verticalLayout_17->addWidget(labelWeather1_1);

        verticalLayout_17->setStretch(0, 3);
        verticalLayout_17->setStretch(1, 2);

        horizontalLayout_10->addLayout(verticalLayout_17);

        verticalLayout_12 = new QVBoxLayout();
        verticalLayout_12->setSpacing(0);
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        labelWeather2 = new QLabel(widgetWeather);
        labelWeather2->setObjectName(QString::fromUtf8("labelWeather2"));
        labelWeather2->setMinimumSize(QSize(159, 50));
        labelWeather2->setMaximumSize(QSize(159, 50));
        labelWeather2->setStyleSheet(QString::fromUtf8("background-color: rgb(74,74,74);\n"
"border-radius: 7px;\n"
"border-bottom-right-radius:0px;\n"
"border-bottom-left-radius:0px;"));
        labelWeather2->setPixmap(QPixmap(QString::fromUtf8(":/DuoYun.png")));
        labelWeather2->setScaledContents(false);
        labelWeather2->setAlignment(Qt::AlignCenter);

        verticalLayout_12->addWidget(labelWeather2);

        labelWeather2_1 = new QLabel(widgetWeather);
        labelWeather2_1->setObjectName(QString::fromUtf8("labelWeather2_1"));
        labelWeather2_1->setFont(font);
        labelWeather2_1->setStyleSheet(QString::fromUtf8("background-color: rgb(74,74,74);\n"
"border-radius: 7px;\n"
"border-top-right-radius:0px;\n"
"border-top-left-radius:0px;;"));
        labelWeather2_1->setAlignment(Qt::AlignCenter);

        verticalLayout_12->addWidget(labelWeather2_1);

        verticalLayout_12->setStretch(0, 3);
        verticalLayout_12->setStretch(1, 2);

        horizontalLayout_10->addLayout(verticalLayout_12);

        verticalLayout_15 = new QVBoxLayout();
        verticalLayout_15->setSpacing(0);
        verticalLayout_15->setObjectName(QString::fromUtf8("verticalLayout_15"));
        labelWeather3 = new QLabel(widgetWeather);
        labelWeather3->setObjectName(QString::fromUtf8("labelWeather3"));
        labelWeather3->setMinimumSize(QSize(0, 50));
        labelWeather3->setMaximumSize(QSize(16777214, 50));
        labelWeather3->setStyleSheet(QString::fromUtf8("background-color: rgb(74,74,74);\n"
"border-radius: 7px;\n"
"border-bottom-right-radius:0px;\n"
"border-bottom-left-radius:0px;"));
        labelWeather3->setPixmap(QPixmap(QString::fromUtf8(":/sun.png")));
        labelWeather3->setAlignment(Qt::AlignCenter);

        verticalLayout_15->addWidget(labelWeather3);

        labelWeather3_1 = new QLabel(widgetWeather);
        labelWeather3_1->setObjectName(QString::fromUtf8("labelWeather3_1"));
        labelWeather3_1->setFont(font);
        labelWeather3_1->setStyleSheet(QString::fromUtf8("background-color: rgb(74,74,74);\n"
"border-radius: 7px;\n"
"border-top-right-radius:0px;\n"
"border-top-left-radius:0px;"));
        labelWeather3_1->setAlignment(Qt::AlignCenter);

        verticalLayout_15->addWidget(labelWeather3_1);

        verticalLayout_15->setStretch(0, 3);
        verticalLayout_15->setStretch(1, 2);

        horizontalLayout_10->addLayout(verticalLayout_15);

        verticalLayout_14 = new QVBoxLayout();
        verticalLayout_14->setSpacing(0);
        verticalLayout_14->setObjectName(QString::fromUtf8("verticalLayout_14"));
        labelWeather4 = new QLabel(widgetWeather);
        labelWeather4->setObjectName(QString::fromUtf8("labelWeather4"));
        labelWeather4->setMinimumSize(QSize(0, 50));
        labelWeather4->setMaximumSize(QSize(16777215, 50));
        labelWeather4->setStyleSheet(QString::fromUtf8("background-color: rgb(74,74,74);\n"
"border-radius: 7px;\n"
"border-bottom-right-radius:0px;\n"
"border-bottom-left-radius:0px;"));
        labelWeather4->setPixmap(QPixmap(QString::fromUtf8(":/sun.png")));
        labelWeather4->setAlignment(Qt::AlignCenter);

        verticalLayout_14->addWidget(labelWeather4);

        labelWeather4_1 = new QLabel(widgetWeather);
        labelWeather4_1->setObjectName(QString::fromUtf8("labelWeather4_1"));
        labelWeather4_1->setFont(font);
        labelWeather4_1->setStyleSheet(QString::fromUtf8("background-color: rgb(74,74,74);\n"
"border-radius: 7px;\n"
"border-top-right-radius:0px;\n"
"border-top-left-radius:0px;"));
        labelWeather4_1->setAlignment(Qt::AlignCenter);

        verticalLayout_14->addWidget(labelWeather4_1);

        verticalLayout_14->setStretch(0, 3);
        verticalLayout_14->setStretch(1, 2);

        horizontalLayout_10->addLayout(verticalLayout_14);

        verticalLayout_16 = new QVBoxLayout();
        verticalLayout_16->setSpacing(0);
        verticalLayout_16->setObjectName(QString::fromUtf8("verticalLayout_16"));
        labelWeather5 = new QLabel(widgetWeather);
        labelWeather5->setObjectName(QString::fromUtf8("labelWeather5"));
        labelWeather5->setMinimumSize(QSize(0, 50));
        labelWeather5->setMaximumSize(QSize(16777215, 50));
        labelWeather5->setStyleSheet(QString::fromUtf8("background-color: rgb(74,74,74);\n"
"border-radius: 7px;\n"
"border-bottom-right-radius:0px;\n"
"border-bottom-left-radius:0px;"));
        labelWeather5->setPixmap(QPixmap(QString::fromUtf8(":/sun.png")));
        labelWeather5->setAlignment(Qt::AlignCenter);

        verticalLayout_16->addWidget(labelWeather5);

        labelWeather5_1 = new QLabel(widgetWeather);
        labelWeather5_1->setObjectName(QString::fromUtf8("labelWeather5_1"));
        labelWeather5_1->setFont(font);
        labelWeather5_1->setStyleSheet(QString::fromUtf8("background-color: rgb(74,74,74);\n"
"border-radius: 7px;\n"
"border-top-right-radius:0px;\n"
"border-top-left-radius:0px;"));
        labelWeather5_1->setAlignment(Qt::AlignCenter);

        verticalLayout_16->addWidget(labelWeather5_1);

        verticalLayout_16->setStretch(0, 3);
        verticalLayout_16->setStretch(1, 2);

        horizontalLayout_10->addLayout(verticalLayout_16);

        verticalLayout_13 = new QVBoxLayout();
        verticalLayout_13->setSpacing(0);
        verticalLayout_13->setObjectName(QString::fromUtf8("verticalLayout_13"));
        labelWeather6 = new QLabel(widgetWeather);
        labelWeather6->setObjectName(QString::fromUtf8("labelWeather6"));
        labelWeather6->setMinimumSize(QSize(0, 50));
        labelWeather6->setMaximumSize(QSize(16777215, 50));
        labelWeather6->setStyleSheet(QString::fromUtf8("background-color: rgb(74,74,74);\n"
"border-radius: 7px;\n"
"border-bottom-right-radius:0px;\n"
"border-bottom-left-radius:0px;"));
        labelWeather6->setPixmap(QPixmap(QString::fromUtf8(":/sun.png")));
        labelWeather6->setAlignment(Qt::AlignCenter);

        verticalLayout_13->addWidget(labelWeather6);

        labelWeather6_1 = new QLabel(widgetWeather);
        labelWeather6_1->setObjectName(QString::fromUtf8("labelWeather6_1"));
        labelWeather6_1->setFont(font);
        labelWeather6_1->setStyleSheet(QString::fromUtf8("background-color: rgb(74,74,74);\n"
"border-radius: 7px;\n"
"border-top-right-radius:0px;\n"
"border-top-left-radius:0px;"));
        labelWeather6_1->setAlignment(Qt::AlignCenter);

        verticalLayout_13->addWidget(labelWeather6_1);

        verticalLayout_13->setStretch(1, 2);

        horizontalLayout_10->addLayout(verticalLayout_13);


        verticalLayout_25->addWidget(widgetWeather);

        widget0401 = new QWidget(widget04);
        widget0401->setObjectName(QString::fromUtf8("widget0401"));
        widget0401->setMinimumSize(QSize(0, 130));
        verticalLayout_26 = new QVBoxLayout(widget0401);
        verticalLayout_26->setSpacing(0);
        verticalLayout_26->setObjectName(QString::fromUtf8("verticalLayout_26"));
        verticalLayout_26->setContentsMargins(0, 0, 0, 0);
        widgetLine1 = new QWidget(widget0401);
        widgetLine1->setObjectName(QString::fromUtf8("widgetLine1"));
        widgetLine1->setMinimumSize(QSize(0, 65));
        widgetLine1->setMaximumSize(QSize(16777215, 16777215));
        QFont font3;
        font3.setPointSize(9);
        widgetLine1->setFont(font3);
        widgetLine1->setStyleSheet(QString::fromUtf8("background-color: rgb(89, 89, 89);\n"
"border-top-left-radius: 5px;\n"
"border-top-right-radius: 5px;"));

        verticalLayout_26->addWidget(widgetLine1);

        widgetLine2 = new QWidget(widget0401);
        widgetLine2->setObjectName(QString::fromUtf8("widgetLine2"));
        widgetLine2->setMinimumSize(QSize(0, 65));
        widgetLine2->setMaximumSize(QSize(16777215, 80));
        widgetLine2->setStyleSheet(QString::fromUtf8("background-color: rgb(89, 89, 89);\n"
"border-bottom-left-radius: 5px;\n"
"border-bottom-right-radius: 5px;"));

        verticalLayout_26->addWidget(widgetLine2);


        verticalLayout_25->addWidget(widget0401);

        widgetAir = new QWidget(widget04);
        widgetAir->setObjectName(QString::fromUtf8("widgetAir"));
        widgetAir->setMinimumSize(QSize(0, 35));
        widgetAir->setStyleSheet(QString::fromUtf8("color:rgb(225,225,225);"));
        horizontalLayout_8 = new QHBoxLayout(widgetAir);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        horizontalLayout_8->setContentsMargins(0, 0, 0, 0);
        labelAIR1 = new QLabel(widgetAir);
        labelAIR1->setObjectName(QString::fromUtf8("labelAIR1"));
        labelAIR1->setFont(font);
        labelAIR1->setStyleSheet(QString::fromUtf8("background-color: rgb(150, 213, 32);\n"
"border-radius: 5px;"));
        labelAIR1->setAlignment(Qt::AlignCenter);

        horizontalLayout_8->addWidget(labelAIR1);

        labelAIR2 = new QLabel(widgetAir);
        labelAIR2->setObjectName(QString::fromUtf8("labelAIR2"));
        labelAIR2->setFont(font);
        labelAIR2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 187, 69);\n"
"border-radius: 5px;"));
        labelAIR2->setAlignment(Qt::AlignCenter);

        horizontalLayout_8->addWidget(labelAIR2);

        labelAIR3 = new QLabel(widgetAir);
        labelAIR3->setObjectName(QString::fromUtf8("labelAIR3"));
        labelAIR3->setFont(font);
        labelAIR3->setStyleSheet(QString::fromUtf8("background-color: rgb(150, 213, 32);\n"
"border-radius: 5px;"));
        labelAIR3->setAlignment(Qt::AlignCenter);

        horizontalLayout_8->addWidget(labelAIR3);

        labelAIR4 = new QLabel(widgetAir);
        labelAIR4->setObjectName(QString::fromUtf8("labelAIR4"));
        labelAIR4->setFont(font);
        labelAIR4->setStyleSheet(QString::fromUtf8("background-color: rgb(150, 213, 32);\n"
"border-radius: 5px;"));
        labelAIR4->setAlignment(Qt::AlignCenter);

        horizontalLayout_8->addWidget(labelAIR4);

        labelAIR5 = new QLabel(widgetAir);
        labelAIR5->setObjectName(QString::fromUtf8("labelAIR5"));
        labelAIR5->setFont(font);
        labelAIR5->setStyleSheet(QString::fromUtf8("background-color: rgb(150, 213, 32);\n"
"border-radius: 5px;"));
        labelAIR5->setAlignment(Qt::AlignCenter);

        horizontalLayout_8->addWidget(labelAIR5);

        labelAIR6 = new QLabel(widgetAir);
        labelAIR6->setObjectName(QString::fromUtf8("labelAIR6"));
        labelAIR6->setFont(font);
        labelAIR6->setStyleSheet(QString::fromUtf8("background-color: rgb(150, 213, 32);\n"
"border-radius: 5px;"));
        labelAIR6->setAlignment(Qt::AlignCenter);

        horizontalLayout_8->addWidget(labelAIR6);


        verticalLayout_25->addWidget(widgetAir);

        widgetWind = new QWidget(widget04);
        widgetWind->setObjectName(QString::fromUtf8("widgetWind"));
        widgetWind->setMinimumSize(QSize(0, 35));
        widgetWind->setStyleSheet(QString::fromUtf8("color:rgb(225,225,225);"));
        horizontalLayout_11 = new QHBoxLayout(widgetWind);
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        horizontalLayout_11->setContentsMargins(0, 0, 0, 0);
        verticalLayout_18 = new QVBoxLayout();
        verticalLayout_18->setSpacing(0);
        verticalLayout_18->setObjectName(QString::fromUtf8("verticalLayout_18"));
        labelWind1 = new QLabel(widgetWind);
        labelWind1->setObjectName(QString::fromUtf8("labelWind1"));
        labelWind1->setFont(font);
        labelWind1->setStyleSheet(QString::fromUtf8("background-color: rgb(89, 89, 89);\n"
"border-radius: 7px;\n"
"border-bottom-right-radius:0px;\n"
"border-bottom-left-radius:0px;"));
        labelWind1->setAlignment(Qt::AlignCenter);

        verticalLayout_18->addWidget(labelWind1);

        labelWind1_1 = new QLabel(widgetWind);
        labelWind1_1->setObjectName(QString::fromUtf8("labelWind1_1"));
        labelWind1_1->setFont(font);
        labelWind1_1->setStyleSheet(QString::fromUtf8("background-color: rgb(89, 89, 89);\n"
"border-radius: 7px;\n"
"border-top-right-radius:0px;\n"
"border-top-left-radius:0px;"));
        labelWind1_1->setAlignment(Qt::AlignCenter);

        verticalLayout_18->addWidget(labelWind1_1);


        horizontalLayout_11->addLayout(verticalLayout_18);

        verticalLayout_19 = new QVBoxLayout();
        verticalLayout_19->setSpacing(0);
        verticalLayout_19->setObjectName(QString::fromUtf8("verticalLayout_19"));
        labelWind2 = new QLabel(widgetWind);
        labelWind2->setObjectName(QString::fromUtf8("labelWind2"));
        labelWind2->setFont(font);
        labelWind2->setStyleSheet(QString::fromUtf8("background-color: rgb(89, 89, 89);\n"
"border-radius: 7px;\n"
"border-bottom-right-radius:0px;\n"
"border-bottom-left-radius:0px;"));
        labelWind2->setAlignment(Qt::AlignCenter);

        verticalLayout_19->addWidget(labelWind2);

        labelWind2_1 = new QLabel(widgetWind);
        labelWind2_1->setObjectName(QString::fromUtf8("labelWind2_1"));
        labelWind2_1->setFont(font);
        labelWind2_1->setStyleSheet(QString::fromUtf8("background-color: rgb(89, 89, 89);\n"
"border-radius: 7px;\n"
"border-top-right-radius:0px;\n"
"border-top-left-radius:0px;;"));
        labelWind2_1->setAlignment(Qt::AlignCenter);

        verticalLayout_19->addWidget(labelWind2_1);


        horizontalLayout_11->addLayout(verticalLayout_19);

        verticalLayout_20 = new QVBoxLayout();
        verticalLayout_20->setSpacing(0);
        verticalLayout_20->setObjectName(QString::fromUtf8("verticalLayout_20"));
        labelWind3 = new QLabel(widgetWind);
        labelWind3->setObjectName(QString::fromUtf8("labelWind3"));
        labelWind3->setFont(font);
        labelWind3->setStyleSheet(QString::fromUtf8("background-color: rgb(89, 89, 89);\n"
"border-radius: 7px;\n"
"border-bottom-right-radius:0px;\n"
"border-bottom-left-radius:0px;"));
        labelWind3->setAlignment(Qt::AlignCenter);

        verticalLayout_20->addWidget(labelWind3);

        labelWind3_1 = new QLabel(widgetWind);
        labelWind3_1->setObjectName(QString::fromUtf8("labelWind3_1"));
        labelWind3_1->setFont(font);
        labelWind3_1->setStyleSheet(QString::fromUtf8("background-color: rgb(89, 89, 89);\n"
"border-radius: 7px;\n"
"border-top-right-radius:0px;\n"
"border-top-left-radius:0px;"));
        labelWind3_1->setAlignment(Qt::AlignCenter);

        verticalLayout_20->addWidget(labelWind3_1);


        horizontalLayout_11->addLayout(verticalLayout_20);

        verticalLayout_21 = new QVBoxLayout();
        verticalLayout_21->setSpacing(0);
        verticalLayout_21->setObjectName(QString::fromUtf8("verticalLayout_21"));
        labelWind4 = new QLabel(widgetWind);
        labelWind4->setObjectName(QString::fromUtf8("labelWind4"));
        labelWind4->setFont(font);
        labelWind4->setStyleSheet(QString::fromUtf8("background-color: rgb(89, 89, 89);\n"
"border-radius: 7px;\n"
"border-bottom-right-radius:0px;\n"
"border-bottom-left-radius:0px;"));
        labelWind4->setAlignment(Qt::AlignCenter);

        verticalLayout_21->addWidget(labelWind4);

        labelWind4_1 = new QLabel(widgetWind);
        labelWind4_1->setObjectName(QString::fromUtf8("labelWind4_1"));
        labelWind4_1->setFont(font);
        labelWind4_1->setStyleSheet(QString::fromUtf8("background-color: rgb(89, 89, 89);\n"
"border-radius: 7px;\n"
"border-top-right-radius:0px;\n"
"border-top-left-radius:0px;"));
        labelWind4_1->setAlignment(Qt::AlignCenter);

        verticalLayout_21->addWidget(labelWind4_1);


        horizontalLayout_11->addLayout(verticalLayout_21);

        verticalLayout_22 = new QVBoxLayout();
        verticalLayout_22->setSpacing(0);
        verticalLayout_22->setObjectName(QString::fromUtf8("verticalLayout_22"));
        labelWind5 = new QLabel(widgetWind);
        labelWind5->setObjectName(QString::fromUtf8("labelWind5"));
        labelWind5->setFont(font);
        labelWind5->setStyleSheet(QString::fromUtf8("background-color: rgb(89, 89, 89);\n"
"border-radius: 7px;\n"
"border-bottom-right-radius:0px;\n"
"border-bottom-left-radius:0px;"));
        labelWind5->setAlignment(Qt::AlignCenter);

        verticalLayout_22->addWidget(labelWind5);

        labelWind5_1 = new QLabel(widgetWind);
        labelWind5_1->setObjectName(QString::fromUtf8("labelWind5_1"));
        labelWind5_1->setFont(font);
        labelWind5_1->setStyleSheet(QString::fromUtf8("background-color: rgb(89, 89, 89);\n"
"border-radius: 7px;\n"
"border-top-right-radius:0px;\n"
"border-top-left-radius:0px;"));
        labelWind5_1->setAlignment(Qt::AlignCenter);

        verticalLayout_22->addWidget(labelWind5_1);


        horizontalLayout_11->addLayout(verticalLayout_22);

        verticalLayout_23 = new QVBoxLayout();
        verticalLayout_23->setSpacing(0);
        verticalLayout_23->setObjectName(QString::fromUtf8("verticalLayout_23"));
        labelWind6 = new QLabel(widgetWind);
        labelWind6->setObjectName(QString::fromUtf8("labelWind6"));
        labelWind6->setFont(font);
        labelWind6->setStyleSheet(QString::fromUtf8("background-color: rgb(89, 89, 89);\n"
"border-radius: 7px;\n"
"border-bottom-right-radius:0px;\n"
"border-bottom-left-radius:0px;"));
        labelWind6->setAlignment(Qt::AlignCenter);

        verticalLayout_23->addWidget(labelWind6);

        labelWind6_1 = new QLabel(widgetWind);
        labelWind6_1->setObjectName(QString::fromUtf8("labelWind6_1"));
        labelWind6_1->setFont(font);
        labelWind6_1->setStyleSheet(QString::fromUtf8("background-color: rgb(89, 89, 89);\n"
"border-radius: 7px;\n"
"border-top-right-radius:0px;\n"
"border-top-left-radius:0px;"));
        labelWind6_1->setAlignment(Qt::AlignCenter);

        verticalLayout_23->addWidget(labelWind6_1);


        horizontalLayout_11->addLayout(verticalLayout_23);


        verticalLayout_25->addWidget(widgetWind);


        verticalLayout_24->addWidget(widget04);


        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "weather", nullptr));
        pushButtonBack->setText(QString());
        labelDate->setText(QApplication::translate("Widget", "2025/11/6  \346\230\237\346\234\237\345\233\233", nullptr));
        labelWeathericon->setText(QString());
        labelTem->setText(QApplication::translate("Widget", "23\342\204\203", nullptr));
        labelWeather->setText(QApplication::translate("Widget", "      \346\231\264\345\244\251    ", nullptr));
        labelCity->setText(QApplication::translate("Widget", "\346\267\261\345\234\263\345\270\202", nullptr));
        label->setText(QApplication::translate("Widget", "                        \346\254\242\350\277\216\346\237\245\347\234\213\345\244\251\346\260\224\351\242\204\346\212\245", nullptr));
        labelTemRange->setText(QApplication::translate("Widget", "20\342\204\203~26\342\204\203", nullptr));
        labelClothes->setText(QApplication::translate("Widget", "\346\204\237\345\206\222\346\214\207\346\225\260\357\274\232\345\220\204\347\261\273\344\272\272\347\276\244\345\217\257\344\273\245\350\207\252\347\224\261\346\264\273\345\212\250", nullptr));
        labelFX->setText(QString());
        labelFXType->setText(QApplication::translate("Widget", "\344\270\234\345\215\227\351\243\216", nullptr));
        labelFXLevel->setText(QApplication::translate("Widget", "2\347\272\247", nullptr));
        labelPR->setText(QString());
        labelPRType->setText(QApplication::translate("Widget", "Pressure", nullptr));
        labelPRLevel->setText(QApplication::translate("Widget", "24", nullptr));
        labelAIR->setText(QString());
        labelAIRType->setText(QApplication::translate("Widget", "\347\251\272\346\260\224\350\264\250\351\207\217", nullptr));
        labelAIRLevel->setText(QApplication::translate("Widget", "\344\274\230", nullptr));
        labelSD->setText(QString());
        labelSDType->setText(QApplication::translate("Widget", "\346\271\277\345\272\246", nullptr));
        labelSDLevel->setText(QApplication::translate("Widget", "85%", nullptr));
        labelDay1->setText(QApplication::translate("Widget", "\346\230\250\345\244\251", nullptr));
        labelDay1_1->setText(QApplication::translate("Widget", "11/06", nullptr));
        labelDay2->setText(QApplication::translate("Widget", "\344\273\212\345\244\251", nullptr));
        labelDay2_1->setText(QApplication::translate("Widget", "11/07", nullptr));
        labelDay3->setText(QApplication::translate("Widget", "\346\230\216\345\244\251", nullptr));
        labelDay3_1->setText(QApplication::translate("Widget", "11/08", nullptr));
        labelDay4->setText(QApplication::translate("Widget", "\345\220\216\345\244\251", nullptr));
        labelDay4_1->setText(QApplication::translate("Widget", "11/09", nullptr));
        labelDay5->setText(QApplication::translate("Widget", "\345\244\247\345\220\216\345\244\251", nullptr));
        labelDay5_1->setText(QApplication::translate("Widget", "11/10", nullptr));
        labelDay6->setText(QApplication::translate("Widget", "\345\244\247\345\244\247\345\220\216\345\244\251", nullptr));
        labelDay6_1->setText(QApplication::translate("Widget", "11/11", nullptr));
        labelWeather1->setText(QString());
        labelWeather1_1->setText(QApplication::translate("Widget", "\346\231\264\345\244\251", nullptr));
        labelWeather2->setText(QString());
        labelWeather2_1->setText(QApplication::translate("Widget", "\345\244\232\344\272\221", nullptr));
        labelWeather3->setText(QString());
        labelWeather3_1->setText(QApplication::translate("Widget", "\346\231\264\345\244\251", nullptr));
        labelWeather4->setText(QString());
        labelWeather4_1->setText(QApplication::translate("Widget", "\346\231\264\345\244\251", nullptr));
        labelWeather5->setText(QString());
        labelWeather5_1->setText(QApplication::translate("Widget", "\346\231\264\345\244\251", nullptr));
        labelWeather6->setText(QString());
        labelWeather6_1->setText(QApplication::translate("Widget", "\346\231\264\345\244\251", nullptr));
        labelAIR1->setText(QApplication::translate("Widget", "\344\274\230", nullptr));
        labelAIR2->setText(QApplication::translate("Widget", "\350\211\257", nullptr));
        labelAIR3->setText(QApplication::translate("Widget", "\344\274\230", nullptr));
        labelAIR4->setText(QApplication::translate("Widget", "\344\274\230", nullptr));
        labelAIR5->setText(QApplication::translate("Widget", "\344\274\230", nullptr));
        labelAIR6->setText(QApplication::translate("Widget", "\344\274\230", nullptr));
        labelWind1->setText(QApplication::translate("Widget", "\344\270\234\345\215\227\351\243\216", nullptr));
        labelWind1_1->setText(QApplication::translate("Widget", "2\347\272\247", nullptr));
        labelWind2->setText(QApplication::translate("Widget", "\344\270\234\345\215\227\351\243\216", nullptr));
        labelWind2_1->setText(QApplication::translate("Widget", "2\347\272\247", nullptr));
        labelWind3->setText(QApplication::translate("Widget", "\344\270\234\345\215\227\351\243\216", nullptr));
        labelWind3_1->setText(QApplication::translate("Widget", "2\347\272\247", nullptr));
        labelWind4->setText(QApplication::translate("Widget", "\344\270\234\345\215\227\351\243\216", nullptr));
        labelWind4_1->setText(QApplication::translate("Widget", "2\347\272\247", nullptr));
        labelWind5->setText(QApplication::translate("Widget", "\344\270\234\345\215\227\351\243\216", nullptr));
        labelWind5_1->setText(QApplication::translate("Widget", "2\347\272\247", nullptr));
        labelWind6->setText(QApplication::translate("Widget", "\344\270\234\345\215\227\351\243\216", nullptr));
        labelWind6_1->setText(QApplication::translate("Widget", "2\347\272\247", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
